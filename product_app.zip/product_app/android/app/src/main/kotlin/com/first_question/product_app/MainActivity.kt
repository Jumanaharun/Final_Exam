package com.first_question.product_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
