class Api

{

  static const mainUrl="https://fakestoreapi.com";

  static const getAllProducts="$mainUrl/products";

}