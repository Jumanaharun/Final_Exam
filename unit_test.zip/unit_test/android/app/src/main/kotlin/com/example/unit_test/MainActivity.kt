package com.example.unit_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
