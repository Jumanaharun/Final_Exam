class MyFunction {

  int perHourPayment = 400;
  int extraHourPayment = 600;

  //function for calculate salary
  int calculateSalary(int hour) {

    if(hour<=40){
      return hour * perHourPayment;
    }

    else {
      int prevh= hour-40;
      int newh= prevh* extraHourPayment;
      return 40*perHourPayment+newh;
    }

  }
}